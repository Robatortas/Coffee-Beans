IT IS NOT RECOMENDED TO USE THE LEGACY VERSION OF THIS APPLICATION.

Coffee Beans is a lightweight application to download videos from youtube.

I felt the need to create a program with this functionality, since almost all websites
that provide this service are bloated with malware or ads.

So this application is virus free, and has no ads. So you can use it however you want it to!

The code is open source and you can look at it over here: https://github.com/Robatortas/Coffee-Beans

Final warning: DO NOT MOVE THE "Coffee Beans.exe" AND THE "coffee_beans.py" FILES FROM THEIR FOLDERS.

Why? Because the .exe file has the path of the .py file fixated to the current location of the .exe plus the "internal" folder.
Basically, the .exe looks for this: currexelocation/internal/coffee_beans.py , that means that you should NOT change
the .py file name, you CAN change the .exe file's name though.

If you want to have the program on your desktop, just make a shortcut for it!

Enjoy this thing!


By: Robatortas/Nofall