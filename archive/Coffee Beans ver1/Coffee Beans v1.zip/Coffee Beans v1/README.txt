Coffee Beans is a lightweight application to download videos from youtube.

I felt the need to create a program with this functionality, since almost all websites
that provide this service are bloated with malware or ads.

So this application is virus free, and has no ads. So you can use it however you want it to!

The code is open source and you can look at it over here: https://github.com/Robatortas/Coffee-Beans

Only available for windows. I don't have a mac, and I don't intend for that to change. If you have a mac, and want
to make an executable for it, please make a pull request so I can add your contribution to the project.

If you want to run with Mac or Linux you will need the following:
- An installation of Python
- Once you have that, run these commands separately on your terminal:
	pip install pysimplegui
	pip install pytube

Enjoy this thing!


By: Robatortas/Nofall